public class F�rdelar
{
static int FastLearner= 0;
static int Sharpener = 0;
static int ObsessedWithWeapons  = 0;
static int Handsome = 0;

static int Haggler = 0;
static int Cleave = 0;
static int Bandage = 0;

static int Grease = 0;
static int Charge = 0;

static int ToughSkin = 0;
static int OneStepAhead = 0;

static int StrongArms = 0;
static int DEUSVOLT = 0;
static int NinjaBoy = 0;

static int DualWield = 0;
static int NaziZombies= 0;
static int JackOfAllTrades = 0;
static int TheRunningMan = 0;



}