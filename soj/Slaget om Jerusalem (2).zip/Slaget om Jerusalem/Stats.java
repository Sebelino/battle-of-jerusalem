public class Stats
{
static int Health = 50;
static String Faith = "neutral";
static int Exp = 0;
static int Level = 1;
static int SPoints = 200;
static int PPoints = 50;
}