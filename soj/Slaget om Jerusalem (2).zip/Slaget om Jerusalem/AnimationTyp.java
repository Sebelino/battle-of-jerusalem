public class AnimationTyp
{
    Animation[] animationer;
    Tillstand tillstand;

    public AnimationTyp()
    {
        animationer = new Animation[8];
    }
}