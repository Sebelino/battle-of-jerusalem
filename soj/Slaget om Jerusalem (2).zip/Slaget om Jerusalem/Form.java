import java.awt.*;
abstract class Form
{
	protected int x,y;
  abstract public void draw(Graphics2D g);
  abstract public boolean �rIForm(int x, int y);
}
