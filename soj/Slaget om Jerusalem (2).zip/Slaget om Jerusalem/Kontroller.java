class Kontroller
{
    public static boolean up;
    public static boolean right;
    public static boolean down;
    public static boolean left;
    public static boolean c;
}