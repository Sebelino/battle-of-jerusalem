public class Skills
{
static int MedRange = 0;
static int Melee = 0;
static int FirstAid = 0;
static int Surgery = 0;
static int ModRange = 0;
static int Athletics = 0;
static int Explosives = 0;
static int Charm = 0;
}