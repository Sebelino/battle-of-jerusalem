interface GameInterface
{
    public static final double FPS = 60.0;
    public static final int FRAMESIZEX = 1100;
    public static final int FRAMESIZEY = 765;
}