interface SpelplanInterface
{
    static final int MAPX = 600;
    static final int MAPY = 600;
}